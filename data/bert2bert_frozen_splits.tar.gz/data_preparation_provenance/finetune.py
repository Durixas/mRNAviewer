from transformers import (
    MBartForConditionalGeneration,
    Seq2SeqTrainingArguments, Seq2SeqTrainer
)
from transformers import TrainerCallback
import torch
from torch.utils.data import random_split
import os
from transformers import RobertaTokenizerFast
import argparse
import utils.codonBox as cb
import numpy as np
import random


def data_prepare(train_source, train_target, use_box):
    """准备训练数据，从训练文件加载并划分train/eval"""
    data = []
    if use_box:
        # 如果使用box概念，需要转换文件名
        train_source = train_source.replace('c5', 'b5').replace('c3', 'b3')
    
    print(f"Loading training data from:")
    print(f"  Source: {train_source}")
    print(f"  Target: {train_target}")
    
    with open(train_source) as f1, open(train_target) as f2:
        for src, tgt in zip(f1, f2):
            if src.strip() and tgt.strip():  # 跳过空行
                data.append({
                    "translation": {
                        "co": src.strip(),
                        "5u": tgt.strip()
                    }
                })
    
    # 划分训练集和验证集（9:1）
    split = 0.1
    train_size = int((1 - split) * len(data))
    eval_size = len(data) - train_size
    
    train_dataset, eval_dataset = random_split(
        data, 
        lengths=[train_size, eval_size],
        generator=torch.Generator().manual_seed(42)
    )
    
    print(f'Total data size: {len(data)}')
    print(f'Train size: {len(train_dataset)}')
    print(f'Eval size: {len(eval_dataset)}')
    
    return train_dataset, eval_dataset


def finetune_model(args):
    """微调模型主函数"""
    print("="*50)
    print("Starting Fine-tuning Process")
    print("="*50)
    
    # 设置随机种子
    SEED = 42
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(SEED)
    
    # 加载数据
    train_dataset, eval_dataset = data_prepare(
        args.train_source, 
        args.train_target, 
        args.use_box
    )
    
    # 加载预训练模型和tokenizer
    print(f"Loading pretrained model from: {args.pretrained_model}")
    model = MBartForConditionalGeneration.from_pretrained(args.pretrained_model)
    
    print(f"Loading tokenizer from: {args.tokenizer}")
    if args.use_special_tokens:
        tokenizer = RobertaTokenizerFast.from_pretrained(
            args.tokenizer, 
            max_len=512,
            additional_special_tokens=["<CDS>", "<5UTR>", "<3UTR>"]
        )
    else:
        tokenizer = RobertaTokenizerFast.from_pretrained(args.tokenizer, max_len=512)

    # 里程碑保存回调（在达到总 epoch 的某个比例时额外保存一次模型）
    class MilestoneSaveCallback(TrainerCallback):
        def __init__(self, trigger_epoch: float, save_dir: str, tokenizer):
            self.trigger_epoch = trigger_epoch
            self.save_dir = save_dir
            self.tokenizer = tokenizer
            self.saved = False

        def on_epoch_end(self, args_cb, state, control, **kwargs):  # args_cb: TrainingArguments
            # state.epoch 为已完成的 epoch 数（浮点），在每个 epoch 结束时递增
            if not self.saved and state.epoch is not None and state.epoch >= self.trigger_epoch:
                model_cb = kwargs.get('model')
                os.makedirs(self.save_dir, exist_ok=True)
                print(f"[MilestoneSaveCallback] Trigger reached (epoch {state.epoch:.2f} >= {self.trigger_epoch:.2f}). Saving milestone to {self.save_dir}")
                if model_cb is not None:
                    model_cb.save_pretrained(self.save_dir)
                self.tokenizer.save_pretrained(self.save_dir)
                self.saved = True
                # 返回 control 以允许其它回调继续
            return control
    
    # 定义数据整理器
    def data_collator(features: list):
        if args.use_special_tokens:
            inputs = ["<CDS>" + f["translation"]["co"] for f in features]
            # 根据模型类型添加对应的特殊token
            if "5u" in args.finetune_model.lower():
                labels = ["<5UTR>" + f["translation"]["5u"] for f in features]
            else:
                labels = ["<3UTR>" + f["translation"]["5u"] for f in features]
        else:
            inputs = [f["translation"]["co"] for f in features]
            labels = [f["translation"]["5u"] for f in features]
        
        # 使用新的tokenizer API
        input_encodings = tokenizer(
            inputs, 
            truncation=True, 
            padding=True, 
            max_length=512, 
            return_tensors="pt"
        )
        
        target_encodings = tokenizer(
            labels, 
            truncation=True, 
            padding=True, 
            max_length=512, 
            return_tensors="pt"
        )
        
        batch = {
            "input_ids": input_encodings["input_ids"],
            "attention_mask": input_encodings["attention_mask"],
            "labels": target_encodings["input_ids"]
        }
        
        return batch
    
    # 训练配置
    training_args = Seq2SeqTrainingArguments(
        output_dir=args.finetune_model,
        overwrite_output_dir=True,
        fp16=torch.cuda.is_available(),  # 只在GPU可用时使用fp16
        do_train=True,
        do_eval=True,
        evaluation_strategy="epoch",
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=max(1, args.batch_size // 2),
        learning_rate=args.learning_rate,
        num_train_epochs=args.epochs,
        logging_dir=f"{args.finetune_model}/logs",
        logging_steps=100,
        save_strategy="epoch",
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        greater_is_better=False,
        warmup_steps=100,
        weight_decay=0.01,
        report_to=None,  # 不使用wandb等报告工具
    )
    
    # 构造回调列表
    callbacks = []
    if args.save_milestone:
        trigger_epoch = args.milestone_fraction * args.epochs
        milestone_dir = os.path.join(args.finetune_model, args.milestone_suffix)
        print(f"Milestone saving enabled: will save extra snapshot at epoch >= {trigger_epoch:.2f} ({args.milestone_fraction*100:.1f}% of total) -> {milestone_dir}")
        callbacks.append(MilestoneSaveCallback(trigger_epoch, milestone_dir, tokenizer))

    # 创建trainer (按照UTR.py的方式，不传递tokenizer参数)
    trainer = Seq2SeqTrainer(
        model=model,
        args=training_args,
        data_collator=data_collator,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        callbacks=callbacks if callbacks else None,
    )
    
    # 开始训练
    print("Starting training...")
    trainer.train()
    
    # 保存最终模型
    print(f"Saving finetuned model to: {args.finetune_model}")
    trainer.save_model(args.finetune_model)
    tokenizer.save_pretrained(args.finetune_model)
    
    print("Fine-tuning completed!")
    
    return model


def main():
    parser = argparse.ArgumentParser(description="Fine-tune RNA UTR prediction model")
    
    # 必需参数
    parser.add_argument('--tokenizer', required=True, type=str,
                       help='Path to tokenizer directory')
    parser.add_argument('--pretrained_model', required=True, type=str,
                       help='Path to pretrained model directory')
    parser.add_argument('--finetune_model', required=True, type=str,
                       help='Path to save finetuned model')
    parser.add_argument('--train_source', required=True, type=str,
                       help='Path to training source file (e.g., tran_c3.txt)')
    parser.add_argument('--train_target', required=True, type=str,
                       help='Path to training target file (e.g., tran_3u.txt)')
    
    # 可选参数
    parser.add_argument('--use_box', action='store_true',
                       help='Whether to use codon box concept')
    parser.add_argument('--use_special_tokens', action='store_true',
                       help='Whether to use special tokens (<CDS>, <5UTR>, <3UTR>)')
    parser.add_argument('--batch_size', type=int, default=4,
                       help='Training batch size (default: 4)')
    parser.add_argument('--learning_rate', type=float, default=5e-5,
                       help='Learning rate (default: 5e-5)')
    parser.add_argument('--epochs', type=int, default=10,
                       help='Number of training epochs (default: 10)')
    parser.add_argument('--gpu_ids', type=str, default='0',
                       help='GPU IDs to use (default: 0)')
    # 里程碑额外保存相关参数
    parser.add_argument('--save_milestone', action='store_true',
                       help='Enable saving an extra snapshot at a milestone fraction of total epochs')
    parser.add_argument('--milestone_fraction', type=float, default=0.75,
                       help='Fraction of total epochs at which to save milestone snapshot (default: 0.75)')
    parser.add_argument('--milestone_suffix', type=str, default='milestone_75pct',
                       help='Subdirectory name (within finetune_model) for milestone snapshot')
    
    args = parser.parse_args()
    
    # 设置GPU
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_ids
    
    # 检查输入文件是否存在
    if not os.path.exists(args.train_source):
        raise FileNotFoundError(f"Training source file not found: {args.train_source}")
    if not os.path.exists(args.train_target):
        raise FileNotFoundError(f"Training target file not found: {args.train_target}")
    if not os.path.exists(args.tokenizer):
        raise FileNotFoundError(f"Tokenizer directory not found: {args.tokenizer}")
    if not os.path.exists(args.pretrained_model):
        raise FileNotFoundError(f"Pretrained model directory not found: {args.pretrained_model}")
    
    # 创建输出目录
    os.makedirs(args.finetune_model, exist_ok=True)
    
    # 打印配置
    print("Fine-tuning Configuration:")
    print(f"  Tokenizer: {args.tokenizer}")
    print(f"  Pretrained Model: {args.pretrained_model}")
    print(f"  Finetune Model: {args.finetune_model}")
    print(f"  Train Source: {args.train_source}")
    print(f"  Train Target: {args.train_target}")
    print(f"  Use Box: {args.use_box}")
    print(f"  Use Special Tokens: {args.use_special_tokens}")
    print(f"  Batch Size: {args.batch_size}")
    print(f"  Learning Rate: {args.learning_rate}")
    print(f"  Epochs: {args.epochs}")
    print(f"  GPU IDs: {args.gpu_ids}")
    print(f"  Save Milestone: {args.save_milestone}")
    if args.save_milestone:
        print(f"  Milestone Fraction: {args.milestone_fraction}")
        print(f"  Milestone Suffix: {args.milestone_suffix}")
    
    # 开始微调
    finetune_model(args)


if __name__ == '__main__':
    main()