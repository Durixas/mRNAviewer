#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
将tissue_data中预划分的train/val/test CSV文件转换为NCRF++格式的txt文件
并保存到cds_tissue_data目录
"""

import csv
import os
from pathlib import Path
from typing import List, Tuple

# Mapping from codon to (amino acid, codon-box label).
CODON_TO_AMINO_BOX = {
    "TTT": ("F", "a"),
    "TTC": ("F", "b"),
    "TTA": ("L", "c"),
    "TTG": ("L", "d"),
    "TCT": ("S", "b"),
    "TCC": ("S", "f"),
    "TCA": ("S", "h"),
    "TCG": ("S", "g"),
    "AGT": ("S", "j"),
    "AGC": ("S", "r"),
    "TAT": ("Y", "c"),
    "TAC": ("Y", "h"),
    "TAA": ("X", "w"),
    "TAG": ("X", "w"),
    "TGA": ("X", "w"),
    "TGT": ("C", "d"),
    "TGC": ("C", "g"),
    "TGG": ("W", "k"),
    "CTT": ("L", "b"),
    "CTC": ("L", "f"),
    "CTA": ("L", "h"),
    "CTG": ("L", "g"),
    "CCT": ("P", "f"),
    "CCC": ("P", "l"),
    "CCA": ("P", "m"),
    "CCG": ("P", "n"),
    "CAT": ("H", "h"),
    "CAC": ("H", "m"),
    "CAA": ("Q", "o"),
    "CAG": ("Q", "r"),
    "CGT": ("R", "g"),
    "CGC": ("R", "n"),
    "CGA": ("R", "r"),
    "CGG": ("R", "s"),
    "AGA": ("R", "u"),
    "AGG": ("R", "q"),
    "ATT": ("I", "c"),
    "ATC": ("I", "h"),
    "ATA": ("I", "i"),
    "ATG": ("M", "j"),
    "ACT": ("T", "h"),
    "ACC": ("T", "m"),
    "ACA": ("T", "o"),
    "ACG": ("T", "r"),
    "AAT": ("N", "i"),
    "AAC": ("N", "o"),
    "AAA": ("K", "t"),
    "AAG": ("K", "u"),
    "GTT": ("V", "d"),
    "GTC": ("V", "g"),
    "GTA": ("V", "j"),
    "GTG": ("V", "k"),
    "GCT": ("A", "g"),
    "GCC": ("A", "n"),
    "GCA": ("A", "r"),
    "GCG": ("A", "s"),
    "GAT": ("D", "j"),
    "GAC": ("D", "r"),
    "GAA": ("E", "u"),
    "GAG": ("E", "q"),
    "GGT": ("G", "k"),
    "GGC": ("G", "s"),
    "GGA": ("G", "q"),
    "GGG": ("G", "p"),
}

STOP_CODONS = {"TAA", "TAG", "TGA"}


def sanitize_sequence(text: str) -> str:
    """清理序列，去除空格并转大写"""
    return "".join(ch.upper() for ch in text.split())


def build_pairs(protein: str, cds: str) -> List[Tuple[str, str]]:
    """从蛋白质和CDS序列构建(氨基酸, box)对列表"""
    
    protein_clean = sanitize_sequence(protein)
    cds_clean = sanitize_sequence(cds)

    if not protein_clean or not cds_clean:
        raise ValueError("missing protein or CDS sequence")

    if len(cds_clean) % 3 != 0:
        raise ValueError("CDS length is not divisible by three")

    codons = [cds_clean[i : i + 3] for i in range(0, len(cds_clean), 3)]
    amino_acids = list(protein_clean)

    # 如果蛋白质序列比密码子少一个，且最后一个密码子是终止密码子，添加X
    if len(amino_acids) + 1 == len(codons) and codons[-1] in STOP_CODONS:
        amino_acids.append("X")
    
    # 处理蛋白质序列末尾的下划线（终止符号）
    if amino_acids and amino_acids[-1] == "_":
        amino_acids[-1] = "X"

    if len(amino_acids) != len(codons):
        raise ValueError(
            f"amino-acid length mismatch (aa={len(amino_acids)} codons={len(codons)})"
        )

    pairs: List[Tuple[str, str]] = []
    for aa, codon in zip(amino_acids, codons):
        # 将*或_转换为X（终止密码子）
        if aa in ("*", "_"):
            aa = "X"

        try:
            mapped_aa, box = CODON_TO_AMINO_BOX[codon]
        except KeyError as exc:
            raise ValueError(f"unknown codon {codon}") from exc

        if aa != mapped_aa:
            raise ValueError(f"amino-acid mismatch for codon {codon}: {aa} != {mapped_aa}")

        pairs.append((aa, box))

    return pairs


def convert_csv_to_txt(csv_path: Path, output_path: Path) -> Tuple[int, int]:
    """
    将CSV文件转换为NCRF++格式的txt文件
    返回：(成功转换的序列数, 跳过的序列数)
    """
    success_count = 0
    skip_count = 0
    
    with csv_path.open(newline="", encoding="utf-8") as csv_file:
        reader = csv.DictReader(csv_file)
        
        with output_path.open("w", encoding="utf-8") as txt_file:
            for row_idx, row in enumerate(reader, start=2):
                protein = row.get("protein", "").strip()
                cds = row.get("dna", "").strip()
                
                if not protein or not cds:
                    skip_count += 1
                    continue
                
                try:
                    pairs = build_pairs(protein, cds)
                    
                    # 写入NCRF++格式：每行一个(氨基酸 box)，序列之间用空行分隔
                    for aa, box in pairs:
                        txt_file.write(f"{aa} {box}\n")
                    txt_file.write("\n")  # 序列之间的空行
                    
                    success_count += 1
                    
                except ValueError as e:
                    print(f"  ⚠ 跳过第{row_idx}行: {e}")
                    skip_count += 1
                    continue
    
    return success_count, skip_count


def process_all_tissues(tissue_data_dir: Path, output_dir: Path):
    """处理所有组织的数据"""
    
    # 获取所有组织文件夹
    tissue_folders = sorted([
        d for d in tissue_data_dir.iterdir() 
        if d.is_dir()
    ])
    
    print(f"找到 {len(tissue_folders)} 个组织文件夹\n")
    
    total_success = 0
    total_skip = 0
    
    for tissue_folder in tissue_folders:
        tissue_name = tissue_folder.name
        print(f"处理组织: {tissue_name}")
        
        # 创建输出目录
        tissue_output_dir = output_dir / tissue_name
        tissue_output_dir.mkdir(parents=True, exist_ok=True)
        
        # 处理train, val, test三个文件
        for split_name, output_name in [("train", "train.txt"), 
                                         ("val", "dev.txt"),  # val -> dev
                                         ("test", "test.txt")]:
            csv_file = tissue_folder / f"{split_name}.csv"
            
            if not csv_file.exists():
                print(f"  ⚠ 未找到 {split_name}.csv，跳过")
                continue
            
            output_file = tissue_output_dir / output_name
            
            try:
                success, skip = convert_csv_to_txt(csv_file, output_file)
                total_success += success
                total_skip += skip
                
                print(f"  ✓ {split_name:5s} -> {output_name:8s}: "
                      f"{success:6d} 个序列成功, {skip:3d} 个跳过")
                
            except Exception as e:
                print(f"  ✗ {split_name} 转换失败: {e}")
        
        print()
    
    print("="*70)
    print(f"转换完成!")
    print(f"总计: {total_success:,} 个序列成功, {total_skip:,} 个序列跳过")
    print("="*70)


def main():
    # 设置路径
    project_root = Path(__file__).parent.parent
    tissue_data_dir = project_root / "tissue_data"
    output_dir = project_root / "cds_tissue_data"
    
    print("="*70)
    print("将tissue_data转换为NCRF++格式")
    print("="*70)
    print(f"输入目录: {tissue_data_dir}")
    print(f"输出目录: {output_dir}")
    print()
    
    if not tissue_data_dir.exists():
        print(f"错误: 输入目录不存在: {tissue_data_dir}")
        return
    
    process_all_tissues(tissue_data_dir, output_dir)


if __name__ == "__main__":
    main()
