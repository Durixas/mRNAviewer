"""Sequential tissue-specific LoRA, held-out selection and complete test export.

Only an idle physical GPU0 is used. All tissue test CDS and UTR labels plus
the preceding 128-example validation set are excluded from the new training
and validation data. No test metric selects adapters or decoding strategies.
"""
import argparse
import hashlib
import json
import math
import random
import sys
import time
from collections import defaultdict

import utr_v2_common as common
import search_5utr_length_constrained as search
from utr_metrics_v2 import PRIMARY, VERSION, score

ROOT, OUT = common.ROOT, common.OUT
NAME = "5utr_tissue_lora_20261025"
RUN = OUT / "evaluation_results/UTR" / NAME
DATA = OUT / "data" / NAME
METRIC = OUT / "metric/UTR" / NAME
WEIGHTS = OUT / "model_cache" / NAME
SEED = 20261025


def prepare():
    tests = common.load_records("5")
    original_validation = json.loads((OUT / "evaluation_results/UTR/v2/5utr_validation_records.json").read_text())
    forbidden_cds = {r["input_cds"] for r in tests+original_validation}
    forbidden_utr = {r["reference_utr"] for r in tests+original_validation}
    datasets, summary, inputs = {}, [], []
    for directory in sorted((ROOT / "xspec_utr/tissue_data").iterdir()):
        if not directory.is_dir():
            continue
        paths = [directory / "tran_c5.txt", directory / "tran_5u.txt"]
        for path in paths:
            inputs.append({"file": str(path.relative_to(ROOT)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        sources, targets = ([s.strip().upper() for s in p.read_text().splitlines()] for p in paths)
        assert len(sources) == len(targets)
        unique, excluded, conflicting = {}, 0, 0
        for s, t in zip(sources, targets):
            if not s or not t or set(s+t)-set("ACGT"):
                raise ValueError(f"Invalid training DNA: {directory}")
            if s in forbidden_cds or t in forbidden_utr:
                excluded += 1
                continue
            if s in unique and unique[s] != t:
                conflicting += 1
            unique.setdefault(s, t)
        keys = sorted(unique, key=lambda s: hashlib.sha256(f"{SEED}:{s}".encode()).hexdigest())
        nval = max(32, min(64, round(len(keys)*0.15)))
        val_keys, train_keys = keys[:nval], keys[nval:]
        val_targets = {unique[s] for s in val_keys}
        train_keys = [s for s in train_keys if unique[s] not in val_targets]
        def records(keys):
            return [{"tissue": directory.name, "test_sequence": i+1,
                     "input_cds": s, "reference_utr": unique[s]} for i, s in enumerate(keys)]
        train, val = records(train_keys), records(val_keys)
        assert len(train) >= 64 and len(val) >= 16
        assert not ({r["input_cds"] for r in train} & {r["input_cds"] for r in val})
        assert not ({r["reference_utr"] for r in train} & {r["reference_utr"] for r in val})
        datasets[directory.name] = {"train": train, "validation": val}
        summary.append({"tissue": directory.name, "original_training_rows": len(sources),
                        "excluded_test_or_original_validation_rows": excluded,
                        "clean_unique_cds": len(unique), "conflicting_duplicate_rows_kept_first": conflicting,
                        "train_samples": len(train), "validation_samples": len(val),
                        "test_source_overlap": 0, "test_target_overlap": 0})
    common.save_json(RUN / "data_splits.json", datasets)
    search.write_csv(RUN / "data_split_summary.csv", summary)
    common.save_json(RUN / "data_provenance.json", {"seed": SEED, "sources": inputs,
                     "exclusion": "All 29-tissue test CDS and UTR labels; original 128-example validation CDS and labels",
                     "within_tissue_validation": "15% of clean unique CDS, 32-64 samples; deterministic SHA256 order; duplicate validation targets excluded from train"})
    return datasets, tests


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--epochs", type=int, default=8)
    args = parser.parse_args()
    import os
    if not args.prepare_only:
        if os.environ.get("CUDA_VISIBLE_DEVICES") != "0":
            raise RuntimeError("Only idle physical GPU0 is authorized for this run")
        search.guard_gpu(status_dir=RUN)
        if not (search.RUN / "status.json").exists() or json.loads((search.RUN / "status.json").read_text())["stage"] != "complete":
            common.save_json(RUN / "status.json", {"stage": "waiting_for_decoding_search", "time": time.time()})
            print("Waiting for the preceding decoding search to complete", flush=True)
            raise SystemExit(75)
    datasets, tests = prepare()
    if args.prepare_only:
        print("PREPARED", len(datasets), "tissues; test leakage removed", flush=True)
        return
    search.guard_gpu(status_dir=RUN)
    pure_selection = json.loads((search.RUN / "frozen_selection.json").read_text())
    search.test_summary(pure_selection["test_strategies"])
    import torch
    from transformers import AutoTokenizer, get_linear_schedule_with_warmup, LogitsProcessor, LogitsProcessorList
    from bert2bert_generation_v2 import BeamReadyBert2Bert, decode
    from bert2bert_lora import install_lora, adapter_state, load_adapter, atomic_checkpoint
    torch.set_num_threads(4)
    torch.set_num_interop_threads(1)
    torch.cuda.set_per_process_memory_fraction(0.45, 0)
    torch.manual_seed(SEED)
    torch.backends.cuda.matmul.allow_tf32 = False
    sys.path.insert(0, str(ROOT / "xspec_utr/bert2bert_codon_to_5utr"))
    from evaluate_dnabert2 import load_model_from_checkpoint
    directory = common.model_dir("5")
    original = load_model_from_checkpoint(str(directory), "cuda")
    tokenizer = AutoTokenizer.from_pretrained(str(directory), trust_remote_code=True, local_files_only=True)
    # Check exact zero-update equality with real inputs before any optimization.
    probe = tokenizer(datasets["Adrenal_gland"]["train"][0]["input_cds"], truncation=True,
                      max_length=512, return_tensors="pt").to("cuda")
    probe_labels = torch.tensor([[10, 11, original.eos_token_id]], device="cuda")
    with torch.inference_mode():
        before = original(**probe, labels=probe_labels, use_cache=False).logits.clone()
    names = install_lora(original, rank=8, alpha=16, dropout=0.05)
    original.eval()
    with torch.inference_mode():
        after = original(**probe, labels=probe_labels, use_cache=False).logits
    if not torch.equal(before, after):
        raise AssertionError("LoRA installation changed zero-update outputs")
    del before, after, probe, probe_labels
    initial_state = adapter_state(original)
    wrapped = BeamReadyBert2Bert(original).eval()
    trainable = [p for p in original.parameters() if p.requires_grad]
    plan = {"rank": 8, "alpha": 16, "dropout": 0.05, "targets": names,
            "trainable_parameters": sum(p.numel() for p in trainable),
            "optimizer": "AdamW", "pilot_learning_rates": [0.0001, 0.0003],
            "weight_decay": 0.01, "scheduler": "linear, 6% warmup",
            "epochs_max": args.epochs, "early_stopping_patience": 2,
            "batch_size": args.batch_size, "gradient_accumulation": 2,
            "gradient_clip_norm": 1.0, "precision": "float32 weights, fp16 AMP",
            "pilot_tissues": ["Adrenal_gland", "Brain", "Lung"],
            "checkpoint_selection": "held-out token-weighted loss, label_smoothing=0.1",
            "learning_rate_selection": "mean pilot validation-loss improvement vs frozen pretrained model; no test data",
            "zero_update_exact_equality": True,
            "source_checkpoint": str(directory.relative_to(ROOT)),
            "source_weight_mtime_ns": (directory / "model.safetensors").stat().st_mtime_ns,
            "data_splits_sha256": hashlib.sha256((RUN / "data_splits.json").read_bytes()).hexdigest(),
            "seed": SEED, "metric_version": VERSION, "gpu": 0}
    plan_path = RUN / "predeclared_plan.json"
    if plan_path.exists() and json.loads(plan_path.read_text()) != plan:
        raise ValueError("Training plan changed during resume")
    common.save_json(plan_path, plan)
    print("LORA PLAN", json.dumps(plan, indent=2), flush=True)

    encoded = {}
    def tokenized(tissue, split):
        key = (tissue, split)
        if key not in encoded:
            rows = datasets[tissue][split]
            inputs = tokenizer([r["input_cds"] for r in rows], truncation=True, max_length=512)
            labels = tokenizer([r["reference_utr"] for r in rows], add_special_tokens=False,
                               truncation=True, max_length=127)["input_ids"]
            encoded[key] = [{"input_ids": a, "attention_mask": b, "labels": y+[original.eos_token_id]}
                            for a, b, y in zip(inputs["input_ids"], inputs["attention_mask"], labels)]
        return encoded[key]

    def batch(rows):
        features = tokenizer.pad([{k: r[k] for k in ("input_ids", "attention_mask")} for r in rows],
                                 padding=True, return_tensors="pt").to("cuda")
        width = max(len(r["labels"]) for r in rows)
        features["labels"] = torch.tensor([r["labels"]+[-100]*(width-len(r["labels"])) for r in rows], device="cuda")
        return features

    def validation_loss(tissue):
        original.eval()
        rows = tokenized(tissue, "validation")
        loss, tokens = 0.0, 0
        for offset in range(0, len(rows), args.batch_size):
            search.guard_gpu(status_dir=RUN)
            features = batch(rows[offset:offset+args.batch_size])
            n = int((features["labels"] != -100).sum().item())
            with torch.inference_mode(), torch.cuda.amp.autocast(dtype=torch.float16):
                value = original(**features, use_cache=False).loss.item()
            loss += value*n
            tokens += n
        return loss/tokens

    def train(tissue, lr):
        tag = f"lr{lr:g}"
        weight_dir = WEIGHTS / tissue / tag
        best_path, resume_path = weight_dir / "adapter_best.pt", weight_dir / "resume.pt"
        finished = weight_dir / "complete.json"
        if finished.exists():
            return json.loads(finished.read_text())
        torch.manual_seed(SEED)
        load_adapter(original, initial_state)
        optimizer = torch.optim.AdamW(trainable, lr=lr, weight_decay=0.01)
        scaler = torch.cuda.amp.GradScaler()
        train_rows = tokenized(tissue, "train")
        batches = math.ceil(len(train_rows)/args.batch_size)
        steps_per_epoch = math.ceil(batches/2)
        total_steps = steps_per_epoch*args.epochs
        scheduler = get_linear_schedule_with_warmup(optimizer, max(1, int(total_steps*0.06)), total_steps)
        baseline = validation_loss(tissue)
        best, best_epoch, stale, start_epoch = baseline, 0, 0, 1
        history = []
        if resume_path.exists():
            state = torch.load(resume_path, map_location="cpu", weights_only=False)
            load_adapter(original, state["adapter"])
            optimizer.load_state_dict(state["optimizer"])
            scheduler.load_state_dict(state["scheduler"])
            scaler.load_state_dict(state["scaler"])
            best, best_epoch, stale = state["best"], state["best_epoch"], state["stale"]
            start_epoch, history = state["epoch"]+1, state["history"]
        else:
            atomic_checkpoint(best_path, {"adapter": initial_state, "epoch": 0, "validation_loss": baseline})
        for epoch in range(start_epoch, args.epochs+1):
            if stale >= 2:
                break
            torch.manual_seed(SEED+epoch)
            original.train()
            original.encoder.eval()  # Frozen encoder dropout is disabled throughout adaptation.
            order = list(range(len(train_rows)))
            random.Random(SEED+epoch).shuffle(order)
            optimizer.zero_grad(set_to_none=True)
            epoch_loss, epoch_tokens = 0.0, 0
            started = time.monotonic()
            for bi, offset in enumerate(range(0, len(order), args.batch_size)):
                search.guard_gpu(status_dir=RUN)
                features = batch([train_rows[i] for i in order[offset:offset+args.batch_size]])
                n = int((features["labels"] != -100).sum().item())
                accumulation = min(2, batches-(bi//2)*2)
                with torch.cuda.amp.autocast(dtype=torch.float16):
                    raw_loss = original(**features, use_cache=False).loss
                if not torch.isfinite(raw_loss):
                    raise ValueError("Nonfinite training loss")
                scaler.scale(raw_loss/accumulation).backward()
                epoch_loss += raw_loss.item()*n
                epoch_tokens += n
                if (bi+1) % 2 == 0 or bi+1 == batches:
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(trainable, 1.0)
                    old_scale = scaler.get_scale()
                    scaler.step(optimizer)
                    scaler.update()
                    if scaler.get_scale() >= old_scale:
                        scheduler.step()
                    optimizer.zero_grad(set_to_none=True)
                common.save_json(RUN / "status.json", {"stage": "training", "tissue": tissue, "learning_rate": lr,
                    "epoch": epoch, "batch": bi+1, "total_batches": batches, "pid": os.getpid(), "gpu": 0, "time": time.time()})
            val = validation_loss(tissue)
            if val < best-1e-4:
                best, best_epoch, stale = val, epoch, 0
                atomic_checkpoint(best_path, {"adapter": adapter_state(original), "epoch": epoch, "validation_loss": val})
            else:
                stale += 1
            row = {"epoch": epoch, "train_loss": epoch_loss/epoch_tokens, "validation_loss": val,
                   "best_validation_loss": best, "elapsed_seconds": time.monotonic()-started}
            history.append(row)
            print("TRAIN", tissue, tag, json.dumps(row), flush=True)
            atomic_checkpoint(resume_path, {"adapter": adapter_state(original), "optimizer": optimizer.state_dict(),
                "scheduler": scheduler.state_dict(), "scaler": scaler.state_dict(), "epoch": epoch,
                "best": best, "best_epoch": best_epoch, "stale": stale, "history": history})
        result = {"tissue": tissue, "learning_rate": lr, "baseline_validation_loss": baseline,
                  "best_validation_loss": best, "best_epoch": best_epoch, "validation_improvement": baseline-best,
                  "adapter_path": str(best_path.relative_to(ROOT)), "history": history}
        common.save_json(finished, result)
        return result

    choice_path = RUN / "frozen_learning_rate.json"
    if choice_path.exists():
        lr = json.loads(choice_path.read_text())["learning_rate"]
    else:
        pilot = [train(tissue, lr) for lr in plan["pilot_learning_rates"] for tissue in plan["pilot_tissues"]]
        improvements = {lr: sum(r["validation_improvement"] for r in pilot if r["learning_rate"] == lr)/3
                        for lr in plan["pilot_learning_rates"]}
        lr = max(improvements, key=improvements.get)
        common.save_json(choice_path, {"learning_rate": lr, "mean_validation_loss_improvement": improvements,
                                     "pilot_results": pilot, "test_data_used": False})
    all_training = [train(tissue, lr) for tissue in sorted(datasets)]
    common.save_json(RUN / "all_training_results.json", all_training)

    class Bounds(LogitsProcessor):
        def __init__(self, low, high):
            pieces = ["".join(tokenizer.decode([i], skip_special_tokens=True).split()).upper()
                      for i in range(wrapped.config.vocab_size)]
            self.lengths = torch.tensor([len(p) for p in pieces], device="cuda")
            self.valid = torch.tensor([bool(p) and not(set(p)-set("ACGT")) for p in pieces], device="cuda")
            self.low, self.high = low, high
        def __call__(self, input_ids, scores):
            lengths = self.lengths[input_ids].sum(dim=1)
            allowed = self.valid[None, :] & (lengths[:, None]+self.lengths[None, :] <= self.high)
            allowed[:, original.eos_token_id] = lengths >= self.low
            return scores.masked_fill(~allowed, -float("inf"))

    bounds = {}
    def generate(sources, config):
        if "max_nt" not in config:
            return decode(wrapped, tokenizer, sources, config, "cuda")
        key = (config["min_nt"], config["max_nt"])
        if key not in bounds:
            bounds[key] = Bounds(*key)
        params = {k: v for k, v in config.items() if k not in ("min_nt", "max_nt")}
        features = tokenizer(sources, padding=True, truncation=True, max_length=512, return_tensors="pt").to("cuda")
        with torch.inference_mode():
            ids = wrapped.generate(**{k: features[k] for k in ("input_ids", "attention_mask")}, **params,
                                   do_sample=False, early_stopping=True,
                                   logits_processor=LogitsProcessorList([bounds[key]]))
        preds = []
        for tokens in ids.tolist():
            if original.eos_token_id in tokens:
                tokens = tokens[:tokens.index(original.eos_token_id)]
            p = "".join(tokenizer.decode(tokens, skip_special_tokens=True).split()).upper()
            assert key[0] <= len(p) <= key[1] and not(set(p)-set("ACGT"))
            preds.append(p)
        return preds

    first = json.loads((search.RUN / "frozen_selection.json").read_text())
    best_pure = first["test_strategies"][0]
    configs = {"pure_search_validation_winner": next(r["config"] for r in first["ranking"] if r["strategy"] == best_pure),
               "beam4_lp1": {"num_beams": 4, "length_penalty": 1., "min_length": 0, "max_length": 128},
               "beam4_nt80_186": {"num_beams": 4, "length_penalty": 2., "min_length": 0, "max_length": 128, "min_nt": 80, "max_nt": 186},
               "beam4_nt50_150": {"num_beams": 4, "length_penalty": 2., "min_length": 0, "max_length": 128, "min_nt": 50, "max_nt": 150}}
    common.save_json(RUN / "predeclared_decode_grid.json", configs)
    choices_path = RUN / "frozen_tissue_decoding.json"
    if choices_path.exists():
        choices = json.loads(choices_path.read_text())
    else:
        choices, validation_rows = {}, []
        for result in all_training:
            tissue = result["tissue"]
            load_adapter(original, torch.load(ROOT / result["adapter_path"], map_location="cpu", weights_only=False)["adapter"])
            wrapped.eval()
            records = datasets[tissue]["validation"]
            candidates = []
            for name, config in configs.items():
                cache_path = DATA / f"{tissue}_{name}_validation_cache.csv"
                cache = common.read_cache(cache_path)
                todo = sorted({r["input_cds"] for r in records}-set(cache), key=lambda s: (len(s), s))
                for offset in range(0, len(todo), args.batch_size):
                    search.guard_gpu(status_dir=RUN)
                    sources = todo[offset:offset+args.batch_size]
                    preds = generate(sources, config)
                    common.append_predictions(cache_path, zip(sources, preds))
                    cache.update(zip(sources, preds))
                values = [score(cache[r["input_cds"]], r["reference_utr"]) for r in records]
                mean = sum(len(cache[r["input_cds"]]) for r in records)/len(records)
                refmean = sum(len(r["reference_utr"]) for r in records)/len(records)
                m = {k: sum(v[k] for v in values)/len(values) for k in PRIMARY}
                # Fixed validation objective, equal relative emphasis on the four primary metrics.
                quality = (m["jaccard_sliding"]+m["rouge"]+m["bleu"]+1-m["jsd_kmer_spectrum"])/4
                candidates.append({"strategy": name, "config": config, "validation_metrics": m,
                    "validation_mean_nt": mean, "validation_reference_mean_nt": refmean,
                    "length_feasible": mean <= min(search.MEAN_LIMIT_NT, 1.2*refmean), "quality": quality})
                validation_rows.append({"tissue": tissue, "strategy": name, **m, "mean_predicted_length_nt": mean,
                                        "mean_reference_length_nt": refmean, "length_feasible": candidates[-1]["length_feasible"]})
            candidates.sort(key=lambda r: (not r["length_feasible"], -r["quality"]))
            choices[tissue] = {"selected": candidates[0], "ranking": candidates, "selection_split": "held_out_training", "test_used": False}
            common.save_json(RUN / "tissue_decoding_in_progress.json", choices)
        common.save_json(choices_path, choices)
        search.write_csv(METRIC / "validation_decode_grid.csv", validation_rows)
    common.DATA, common.METRIC, common.RUN = DATA, METRIC, RUN
    all_predictions = {}
    for result in all_training:
        tissue = result["tissue"]
        load_adapter(original, torch.load(ROOT / result["adapter_path"], map_location="cpu", weights_only=False)["adapter"])
        wrapped.eval()
        config = choices[tissue]["selected"]["config"]
        records = [r for r in tests if r["tissue"] == tissue]
        cache_path = DATA / f"{tissue}_test_cache.csv"
        cache = common.read_cache(cache_path)
        todo = sorted({r["input_cds"] for r in records}-set(cache), key=lambda s: (len(s), s))
        for offset in range(0, len(todo), args.batch_size):
            search.guard_gpu(status_dir=RUN)
            sources = todo[offset:offset+args.batch_size]
            preds = generate(sources, config)
            common.append_predictions(cache_path, zip(sources, preds))
            cache.update(zip(sources, preds))
            common.save_json(RUN / "status.json", {"stage": "test", "tissue": tissue, "cached_unique": len(cache),
                                                  "pid": os.getpid(), "gpu": 0, "time": time.time()})
        all_predictions.update({(tissue, s): p for s, p in cache.items()})
        print("DECODED", tissue, len(cache), flush=True)
    metadata = {"training_plan": str(plan_path.relative_to(ROOT)), "frozen_tissue_choices": str(choices_path.relative_to(ROOT)),
                "learning_rate": lr, "reference_in_generation": False, "selection_split": "held_out_training_only"}
    common.write_results("5", "bert2bert_tissue_lora", "test", tests, all_predictions, metadata)
    # Reuse the same paired comparison implementation in the LoRA result directory.
    search.METRIC = METRIC
    search.test_summary(["tissue_lora"])
    common.save_json(RUN / "status.json", {"stage": "complete", "pid": os.getpid(), "time": time.time()})


if __name__ == "__main__":
    main()
