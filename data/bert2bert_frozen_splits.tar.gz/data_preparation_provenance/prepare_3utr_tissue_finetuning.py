"""Build held-out tissue splits, excluding every test source and UTR label."""
import hashlib
import json
from pathlib import Path

import utr_v2_common as common

NAME = "3utr_tissue_fullft_small_20261026"
RUN = common.OUT / "evaluation_results/UTR" / NAME
SEED = 20261026


def prepare():
    tests = common.load_records("3")
    old_validation = json.loads((common.OUT / "evaluation_results/UTR/v2/3utr_validation_records.json").read_text())
    forbidden_cds = {r["input_cds"] for r in tests+old_validation}
    forbidden_utr = {r["reference_utr"] for r in tests+old_validation}
    datasets, summary, sources = {}, [], []
    for directory in sorted((common.ROOT / "xspec_utr/tissue_data").iterdir()):
        if not directory.is_dir():
            continue
        paths = [directory / "tran_c3.txt", directory / "tran_3u.txt"]
        for path in paths:
            sources.append({"file": str(path.relative_to(common.ROOT)),
                            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        cds, utr = ([s.strip().upper() for s in p.read_text().splitlines()] for p in paths)
        if len(cds) != len(utr):
            raise ValueError(f"Unpaired training data: {directory}")
        unique, excluded, conflicts = {}, 0, 0
        for s, t in zip(cds, utr):
            if not s or not t or set(s+t)-set("ACGT"):
                raise ValueError(f"Invalid training DNA: {directory}")
            if s in forbidden_cds or t in forbidden_utr:
                excluded += 1
                continue
            conflicts += s in unique and unique[s] != t
            unique.setdefault(s, t)
        keys = sorted(unique, key=lambda s: hashlib.sha256(f"{SEED}:{s}".encode()).hexdigest())
        nval = max(24, min(48, round(len(keys)*0.20)))
        val_keys = keys[:nval]
        val_targets = {unique[s] for s in val_keys}
        train_keys = [s for s in keys[nval:] if unique[s] not in val_targets]
        def records(items):
            return [{"tissue": directory.name, "test_sequence": i+1,
                     "input_cds": s, "reference_utr": unique[s]} for i, s in enumerate(items)]
        train, val = records(train_keys), records(val_keys)
        assert len(train) >= 32 and len(val) >= 24
        assert not ({r["input_cds"] for r in train} & {r["input_cds"] for r in val})
        assert not ({r["reference_utr"] for r in train} & {r["reference_utr"] for r in val})
        datasets[directory.name] = {"train": train, "validation": val}
        summary.append({"tissue": directory.name, "raw_training_rows": len(cds),
                        "excluded_test_or_original_validation_rows": excluded,
                        "clean_unique_cds": len(unique), "conflicts_kept_first": conflicts,
                        "train_samples": len(train), "validation_samples": len(val)})
    assert len(datasets) == 29
    path = RUN / "data_splits.json"
    if path.exists() and json.loads(path.read_text()) != datasets:
        raise ValueError("Frozen splits differ; input data changed")
    common.save_json(path, datasets)
    common.save_json(RUN / "data_provenance.json", {
        "seed": SEED, "inputs": sources, "region": "3utr",
        "exclusion": "All 29-tissue test CDS and UTR labels plus original 128-example validation CDS/labels",
        "split": "20% of clean unique CDS, min24/max48 validation; deterministic SHA256 order; train validation-target overlaps removed",
        "training_records": sum(r["train_samples"] for r in summary),
        "validation_records": sum(r["validation_samples"] for r in summary),
        "test_records": len(tests)})
    from search_5utr_length_constrained import write_csv
    write_csv(RUN / "data_split_summary.csv", summary)
    return datasets, tests


if __name__ == "__main__":
    data, tests = prepare()
    print(f"Prepared {len(data)} tissues; train={sum(len(x['train']) for x in data.values())}; validation={sum(len(x['validation']) for x in data.values())}; test={len(tests)}")
