#!/usr/bin/env python3
"""
按照tissue类型处理raw_data中的CSV文件，生成训练和评估数据集
"""

import os
import pandas as pd
import numpy as np
from pathlib import Path
import re

def extract_tissue_name(filename):
    """从文件名中提取tissue名称"""
    # 匹配模式: prt_vs_rna_with_sequences_<tissue>_<3utr/5utr>.csv
    pattern = r'prt_vs_rna_with_sequences_(.+?)_[35]utr\.csv'
    match = re.search(pattern, filename)
    if match:
        return match.group(1)
    return None

def process_tissue_data(tissue_name, raw_data_dir, output_dir, eval_ratio=0.1):
    """处理单个tissue的数据"""
    print(f"Processing tissue: {tissue_name}")
    
    # 创建输出目录
    tissue_output_dir = Path(output_dir) / tissue_name
    tissue_output_dir.mkdir(parents=True, exist_ok=True)
    
    # 读取3UTR和5UTR数据
    utr3_file = Path(raw_data_dir) / "3utr" / f"prt_vs_rna_with_sequences_{tissue_name}_3utr.csv"
    utr5_file = Path(raw_data_dir) / "5utr" / f"prt_vs_rna_with_sequences_{tissue_name}_5utr.csv"
    
    data_3utr = None
    data_5utr = None
    
    # 读取3UTR数据
    if utr3_file.exists():
        data_3utr = pd.read_csv(utr3_file)
        print(f"  Found 3UTR data: {len(data_3utr)} samples")
    else:
        print(f"  Warning: 3UTR file not found for {tissue_name}")
    
    # 读取5UTR数据
    if utr5_file.exists():
        data_5utr = pd.read_csv(utr5_file)
        print(f"  Found 5UTR data: {len(data_5utr)} samples")
    else:
        print(f"  Warning: 5UTR file not found for {tissue_name}")
    
    # 处理3UTR数据
    if data_3utr is not None and len(data_3utr) > 0:
        # 随机打乱并划分数据
        data_3utr = data_3utr.sample(frac=1, random_state=42).reset_index(drop=True)
        n_eval_3 = max(1, int(len(data_3utr) * eval_ratio))
        
        eval_data_3 = data_3utr[:n_eval_3]
        train_data_3 = data_3utr[n_eval_3:]
        
        # 保存3UTR训练数据
        with open(tissue_output_dir / "tran_c3.txt", 'w') as f:
            f.write('\n'.join(train_data_3['cds'].astype(str)))
        
        with open(tissue_output_dir / "tran_3u.txt", 'w') as f:
            f.write('\n'.join(train_data_3['3utr'].astype(str)))
        
        # 保存3UTR评估数据
        with open(tissue_output_dir / "eval_c3.txt", 'w') as f:
            f.write('\n'.join(eval_data_3['cds'].astype(str)))
        
        with open(tissue_output_dir / "eval_3u.txt", 'w') as f:
            f.write('\n'.join(eval_data_3['3utr'].astype(str)))
        
        print(f"  3UTR: {len(train_data_3)} train, {len(eval_data_3)} eval samples")
    
    # 处理5UTR数据
    if data_5utr is not None and len(data_5utr) > 0:
        # 随机打乱并划分数据
        data_5utr = data_5utr.sample(frac=1, random_state=42).reset_index(drop=True)
        n_eval_5 = max(1, int(len(data_5utr) * eval_ratio))
        
        eval_data_5 = data_5utr[:n_eval_5]
        train_data_5 = data_5utr[n_eval_5:]
        
        # 保存5UTR训练数据
        with open(tissue_output_dir / "tran_c5.txt", 'w') as f:
            f.write('\n'.join(train_data_5['cds'].astype(str)))
        
        with open(tissue_output_dir / "tran_5u.txt", 'w') as f:
            f.write('\n'.join(train_data_5['5utr'].astype(str)))
        
        # 保存5UTR评估数据
        with open(tissue_output_dir / "eval_c5.txt", 'w') as f:
            f.write('\n'.join(eval_data_5['cds'].astype(str)))
        
        with open(tissue_output_dir / "eval_5u.txt", 'w') as f:
            f.write('\n'.join(eval_data_5['5utr'].astype(str)))
        
        print(f"  5UTR: {len(train_data_5)} train, {len(eval_data_5)} eval samples")
    
    print(f"  Saved data to: {tissue_output_dir}")
    return True

def main():
    """主函数"""
    raw_data_dir = "raw_data"
    output_dir = "tissue_data"
    
    # 创建输出目录
    Path(output_dir).mkdir(exist_ok=True)
    
    # 获取所有tissue名称（从3utr文件夹中获取）
    utr3_dir = Path(raw_data_dir) / "3utr"
    tissues = set()
    
    if utr3_dir.exists():
        for csv_file in utr3_dir.glob("*.csv"):
            tissue = extract_tissue_name(csv_file.name)
            if tissue:
                tissues.add(tissue)
    
    # 也从5utr文件夹中获取（以防有不同的tissue）
    utr5_dir = Path(raw_data_dir) / "5utr"
    if utr5_dir.exists():
        for csv_file in utr5_dir.glob("*.csv"):
            tissue = extract_tissue_name(csv_file.name)
            if tissue:
                tissues.add(tissue)
    
    print(f"Found {len(tissues)} tissues: {sorted(tissues)}")
    
    # 处理每个tissue
    processed_count = 0
    for tissue in sorted(tissues):
        try:
            process_tissue_data(tissue, raw_data_dir, output_dir)
            processed_count += 1
        except Exception as e:
            print(f"Error processing {tissue}: {e}")
    
    print(f"\nProcessed {processed_count}/{len(tissues)} tissues successfully")
    print(f"Output saved to: {output_dir}/")
    
    # 显示生成的目录结构
    print("\\nGenerated directory structure:")
    for tissue_dir in sorted(Path(output_dir).iterdir()):
        if tissue_dir.is_dir():
            print(f"  {tissue_dir.name}/")
            for data_file in sorted(tissue_dir.glob("*.txt")):
                with open(data_file) as f:
                    line_count = len(f.readlines())
                print(f"    {data_file.name} ({line_count} lines)")

if __name__ == "__main__":
    main()